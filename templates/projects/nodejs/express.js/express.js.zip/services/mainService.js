// mainService.js

const messageBuild = (message) => {
  return `Message: ${message}!`
}

module.exports = {
  messageBuild
}
